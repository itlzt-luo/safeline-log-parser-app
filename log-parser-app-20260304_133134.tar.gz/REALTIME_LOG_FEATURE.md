# 实时日志监控功能方案

## 📋 问题分析

对于持续写入的日志文件，需要解决以下问题：
1. **自动刷新**: 定期读取新增的日志内容
2. **增量更新**: 只读取新增部分，不重复读取
3. **性能优化**: 避免频繁全量读取大文件
4. **用户体验**: 平滑的数据更新，不影响查看

---

## 🎯 推荐方案

### 方案 1: 定时轮询（简单易实现）⭐⭐⭐⭐

**原理**: 前端定时请求后端，后端记录文件读取位置，只返回新增内容

**优点**:
- 实现简单
- 兼容性好
- 易于控制刷新频率

**缺点**:
- 轮询有延迟
- 增加服务器负载

**适用场景**: 日志更新频率不高（1-30秒一次）

### 方案 2: WebSocket 实时推送（最佳体验）⭐⭐⭐⭐⭐

**原理**: 后端使用文件监听（fs.watch），有新内容立即通过 WebSocket 推送

**优点**:
- 真正的实时性
- 减少不必要的请求
- 用户体验最好

**缺点**:
- 实现复杂
- 需要维护连接
- 服务器资源占用

**适用场景**: 需要高实时性，日志更新频繁

### 方案 3: Server-Sent Events (SSE)（平衡方案）⭐⭐⭐⭐

**原理**: 服务器主动推送数据流，客户端自动重连

**优点**:
- 实现较简单
- 自动重连机制
- 单向推送效率高

**缺点**:
- 仅支持服务器到客户端
- 部分浏览器兼容性

**适用场景**: 只需要服务器推送数据的场景

---

## 💡 推荐实现：方案1 + 方案2 混合

### 架构设计

```
┌─────────────────────────────────────────┐
│         前端 (React)                     │
│  ┌─────────────────────────────────┐   │
│  │  实时监控开关                    │   │
│  │  [⏸️ 暂停] [▶️ 继续] [🔄 刷新]  │   │
│  └─────────────────────────────────┘   │
│                 │                        │
│                 ↓                        │
│  ┌─────────────────────────────────┐   │
│  │  两种模式可切换:                │   │
│  │  - 定时轮询 (默认: 10秒)        │   │
│  │  - WebSocket 实时推送            │   │
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘
                 │
                 ↓
┌─────────────────────────────────────────┐
│         后端 (Express)                   │
│  ┌─────────────────────────────────┐   │
│  │  增量读取 API                    │   │
│  │  /api/logs/watch?path=xxx&pos=0 │   │
│  └─────────────────────────────────┘   │
│                                          │
│  ┌─────────────────────────────────┐   │
│  │  WebSocket 服务                  │   │
│  │  ws://server/logs/watch          │   │
│  └─────────────────────────────────┘   │
│                                          │
│  ┌─────────────────────────────────┐   │
│  │  文件监听器 (fs.watch)           │   │
│  │  检测文件变化 → 读取新内容      │   │
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘
```

---

## 🔧 实现代码

### 1. 后端 - 增量读取 API

```javascript
// server/logWatcher.js
const fs = require('fs');
const readline = require('readline');

class LogWatcher {
  constructor() {
    this.watchers = new Map(); // 存储文件监听器
    this.positions = new Map(); // 存储读取位置
  }

  // 增量读取日志
  async readIncremental(filePath, startPosition = 0) {
    return new Promise((resolve, reject) => {
      const stats = fs.statSync(filePath);
      const fileSize = stats.size;

      // 如果文件没有新内容
      if (startPosition >= fileSize) {
        return resolve({
          logs: [],
          newPosition: startPosition,
          hasMore: false
        });
      }

      const stream = fs.createReadStream(filePath, {
        start: startPosition,
        encoding: 'utf8'
      });

      const rl = readline.createInterface({
        input: stream,
        crlfDelay: Infinity
      });

      const newLogs = [];
      let bytesRead = startPosition;

      rl.on('line', (line) => {
        if (line.trim()) {
          newLogs.push(line);
          bytesRead += Buffer.byteLength(line, 'utf8') + 1; // +1 for newline
        }
      });

      rl.on('close', () => {
        resolve({
          logs: newLogs,
          newPosition: bytesRead,
          hasMore: bytesRead < fileSize
        });
      });

      rl.on('error', reject);
    });
  }

  // 监听文件变化
  watchFile(filePath, callback) {
    if (this.watchers.has(filePath)) {
      return; // 已经在监听
    }

    const watcher = fs.watch(filePath, (eventType) => {
      if (eventType === 'change') {
        const position = this.positions.get(filePath) || 0;
        this.readIncremental(filePath, position)
          .then(result => {
            if (result.logs.length > 0) {
              this.positions.set(filePath, result.newPosition);
              callback(result.logs);
            }
          })
          .catch(err => console.error('Error reading file:', err));
      }
    });

    this.watchers.set(filePath, watcher);
    this.positions.set(filePath, 0);
  }

  // 停止监听
  unwatchFile(filePath) {
    const watcher = this.watchers.get(filePath);
    if (watcher) {
      watcher.close();
      this.watchers.delete(filePath);
      this.positions.delete(filePath);
    }
  }

  // 停止所有监听
  unwatchAll() {
    this.watchers.forEach(watcher => watcher.close());
    this.watchers.clear();
    this.positions.clear();
  }
}

module.exports = new LogWatcher();
```

### 2. 后端 - API 路由

```javascript
// server/index.js 中添加

const logWatcher = require('./logWatcher');

// 增量读取日志
app.get('/api/logs/incremental', async (req, res) => {
  try {
    const { path: logPath, position = 0 } = req.query;
    
    if (!logPath) {
      return res.status(400).json({ error: '缺少日志路径' });
    }

    const result = await logWatcher.readIncremental(
      logPath, 
      parseInt(position) || 0
    );

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// 获取文件当前大小（用于初始化位置）
app.get('/api/logs/size', (req, res) => {
  try {
    const { path: logPath } = req.query;
    
    if (!logPath) {
      return res.status(400).json({ error: '缺少日志路径' });
    }

    const stats = fs.statSync(logPath);
    
    res.json({
      success: true,
      size: stats.size
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});
```

### 3. 前端 - 实时监控 Hook

```javascript
// client/src/hooks/useLogMonitor.js
import { useState, useEffect, useRef, useCallback } from 'react';
import axios from 'axios';

export function useLogMonitor(logPath, options = {}) {
  const {
    interval = 10000, // 轮询间隔(毫秒)
    autoStart = false, // 是否自动开始
    onNewLogs = null,  // 新日志回调
  } = options;

  const [isMonitoring, setIsMonitoring] = useState(autoStart);
  const [position, setPosition] = useState(0);
  const [error, setError] = useState(null);
  const intervalRef = useRef(null);

  // 获取增量日志
  const fetchIncrementalLogs = useCallback(async () => {
    if (!logPath) return;

    try {
      const response = await axios.get('/api/logs/incremental', {
        params: { path: logPath, position }
      });

      const { logs, newPosition } = response.data.data;

      if (logs.length > 0) {
        setPosition(newPosition);
        if (onNewLogs) {
          onNewLogs(logs);
        }
      }

      setError(null);
    } catch (err) {
      setError(err.message);
      console.error('获取增量日志失败:', err);
    }
  }, [logPath, position, onNewLogs]);

  // 开始监控
  const startMonitoring = useCallback(() => {
    if (!logPath) return;
    
    setIsMonitoring(true);
    
    // 立即执行一次
    fetchIncrementalLogs();
    
    // 设置定时器
    intervalRef.current = setInterval(fetchIncrementalLogs, interval);
  }, [logPath, interval, fetchIncrementalLogs]);

  // 停止监控
  const stopMonitoring = useCallback(() => {
    setIsMonitoring(false);
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  // 重置位置（从头开始）
  const resetPosition = useCallback(async () => {
    setPosition(0);
    if (isMonitoring) {
      fetchIncrementalLogs();
    }
  }, [isMonitoring, fetchIncrementalLogs]);

  // 跳到文件末尾
  const seekToEnd = useCallback(async () => {
    try {
      const response = await axios.get('/api/logs/size', {
        params: { path: logPath }
      });
      setPosition(response.data.size);
    } catch (err) {
      console.error('获取文件大小失败:', err);
    }
  }, [logPath]);

  // 自动开始
  useEffect(() => {
    if (autoStart && logPath) {
      startMonitoring();
    }

    return () => {
      stopMonitoring();
    };
  }, [logPath, autoStart]);

  return {
    isMonitoring,
    position,
    error,
    startMonitoring,
    stopMonitoring,
    resetPosition,
    seekToEnd,
    fetchIncrementalLogs
  };
}
```

### 4. 前端 - 监控控制组件

```javascript
// client/src/components/LogMonitor.js
import React, { useState, useCallback } from 'react';
import { useLogMonitor } from '../hooks/useLogMonitor';
import './LogMonitor.css';

function LogMonitor({ logPath, onLogsUpdate }) {
  const [interval, setInterval] = useState(10); // 秒
  const [newLogsCount, setNewLogsCount] = useState(0);

  const handleNewLogs = useCallback((logs) => {
    setNewLogsCount(prev => prev + logs.length);
    if (onLogsUpdate) {
      onLogsUpdate(logs);
    }
  }, [onLogsUpdate]);

  const {
    isMonitoring,
    position,
    error,
    startMonitoring,
    stopMonitoring,
    resetPosition,
    seekToEnd,
    fetchIncrementalLogs
  } = useLogMonitor(logPath, {
    interval: interval * 1000,
    autoStart: false,
    onNewLogs: handleNewLogs
  });

  const handleIntervalChange = (e) => {
    const value = parseInt(e.target.value);
    if (value > 0) {
      setInterval(value);
      if (isMonitoring) {
        stopMonitoring();
        setTimeout(startMonitoring, 100);
      }
    }
  };

  return (
    <div className="log-monitor">
      <div className="monitor-header">
        <h3>📊 实时监控</h3>
        <div className="monitor-status">
          {isMonitoring ? (
            <span className="status-active">● 监控中</span>
          ) : (
            <span className="status-inactive">○ 已暂停</span>
          )}
        </div>
      </div>

      <div className="monitor-controls">
        <div className="control-group">
          <label>刷新间隔:</label>
          <select value={interval} onChange={handleIntervalChange}>
            <option value="5">5秒</option>
            <option value="10">10秒</option>
            <option value="30">30秒</option>
            <option value="60">1分钟</option>
            <option value="300">5分钟</option>
          </select>
        </div>

        <div className="control-buttons">
          {!isMonitoring ? (
            <button 
              className="btn-start" 
              onClick={startMonitoring}
              disabled={!logPath}
            >
              ▶️ 开始监控
            </button>
          ) : (
            <button 
              className="btn-stop" 
              onClick={stopMonitoring}
            >
              ⏸️ 暂停监控
            </button>
          )}

          <button 
            className="btn-refresh" 
            onClick={fetchIncrementalLogs}
            disabled={!logPath}
          >
            🔄 立即刷新
          </button>

          <button 
            className="btn-reset" 
            onClick={resetPosition}
            disabled={!logPath}
          >
            ⏮️ 从头开始
          </button>

          <button 
            className="btn-seek-end" 
            onClick={seekToEnd}
            disabled={!logPath}
          >
            ⏭️ 跳到末尾
          </button>
        </div>
      </div>

      <div className="monitor-info">
        <div className="info-item">
          <span className="info-label">读取位置:</span>
          <span className="info-value">{(position / 1024).toFixed(2)} KB</span>
        </div>
        <div className="info-item">
          <span className="info-label">新增记录:</span>
          <span className="info-value">{newLogsCount} 条</span>
        </div>
        {error && (
          <div className="info-error">
            ⚠️ {error}
          </div>
        )}
      </div>
    </div>
  );
}

export default LogMonitor;
```

### 5. 前端 - 样式

```css
/* client/src/components/LogMonitor.css */
.log-monitor {
  background: linear-gradient(135deg, rgba(67, 233, 123, 0.05) 0%, rgba(56, 211, 159, 0.05) 100%);
  border: 2px solid #43e97b;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
}

.monitor-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 0.75rem;
  border-bottom: 2px solid rgba(67, 233, 123, 0.3);
}

.monitor-header h3 {
  margin: 0;
  color: #43e97b;
  font-size: 1.1rem;
}

.monitor-status {
  font-size: 0.9rem;
}

.status-active {
  color: #43e97b;
  font-weight: 600;
  animation: pulse 2s infinite;
}

.status-inactive {
  color: #999;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.monitor-controls {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.control-group {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.control-group label {
  font-weight: 600;
  color: #333;
}

.control-group select {
  padding: 0.5rem;
  border: 2px solid #e0e0e0;
  border-radius: 6px;
  font-size: 0.9rem;
  cursor: pointer;
  transition: border-color 0.3s;
}

.control-group select:focus {
  outline: none;
  border-color: #43e97b;
}

.control-buttons {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}

.control-buttons button {
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 6px;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-start {
  background: linear-gradient(135deg, #43e97b 0%, #38d39f 100%);
  color: white;
}

.btn-start:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(67, 233, 123, 0.3);
}

.btn-stop {
  background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
  color: white;
}

.btn-stop:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(250, 112, 154, 0.3);
}

.btn-refresh, .btn-reset, .btn-seek-end {
  background: white;
  color: #43e97b;
  border: 2px solid #43e97b;
}

.btn-refresh:hover:not(:disabled),
.btn-reset:hover:not(:disabled),
.btn-seek-end:hover:not(:disabled) {
  background: linear-gradient(135deg, rgba(67, 233, 123, 0.1) 0%, rgba(56, 211, 159, 0.1) 100%);
  transform: translateY(-2px);
}

button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.monitor-info {
  display: flex;
  gap: 2rem;
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid rgba(67, 233, 123, 0.2);
  flex-wrap: wrap;
}

.info-item {
  display: flex;
  gap: 0.5rem;
}

.info-label {
  color: #666;
  font-size: 0.9rem;
}

.info-value {
  color: #43e97b;
  font-weight: 600;
  font-size: 0.9rem;
}

.info-error {
  color: #fa709a;
  font-size: 0.9rem;
  font-weight: 600;
}

@media (max-width: 768px) {
  .control-buttons {
    flex-direction: column;
  }

  .control-buttons button {
    width: 100%;
  }

  .monitor-info {
    flex-direction: column;
    gap: 0.5rem;
  }
}
```

---

## 📊 使用示例

### 在 App.js 中集成

```javascript
import React, { useState, useCallback } from 'react';
import LogMonitor from './components/LogMonitor';
import LogTable from './components/LogTable';

function App() {
  const [logs, setLogs] = useState([]);
  const [currentLogPath, setCurrentLogPath] = useState('');

  // 处理新日志
  const handleNewLogs = useCallback((newLogs) => {
    // 解析新日志
    const parsedLogs = newLogs.map(line => parseLogLine(line));
    
    // 添加到现有日志
    setLogs(prevLogs => [...prevLogs, ...parsedLogs]);
    
    // 可选：限制最大数量，避免内存溢出
    setLogs(prevLogs => prevLogs.slice(-10000));
  }, []);

  return (
    <div className="App">
      {currentLogPath && (
        <LogMonitor 
          logPath={currentLogPath} 
          onLogsUpdate={handleNewLogs}
        />
      )}
      
      <LogTable logs={logs} />
    </div>
  );
}
```

---

## 🎯 高级功能

### 1. 智能暂停

当用户滚动查看历史日志时，自动暂停监控：

```javascript
const [autoScroll, setAutoScroll] = useState(true);

useEffect(() => {
  if (autoScroll && isMonitoring) {
    // 自动滚动到底部
    window.scrollTo(0, document.body.scrollHeight);
  }
}, [logs, autoScroll, isMonitoring]);

// 监听用户滚动
useEffect(() => {
  const handleScroll = () => {
    const isAtBottom = 
      window.innerHeight + window.scrollY >= document.body.scrollHeight - 100;
    setAutoScroll(isAtBottom);
  };

  window.addEventListener('scroll', handleScroll);
  return () => window.removeEventListener('scroll', handleScroll);
}, []);
```

### 2. 日志高亮

新增的日志添加高亮效果：

```javascript
const [highlightedIds, setHighlightedIds] = useState(new Set());

const handleNewLogs = useCallback((newLogs) => {
  const parsedLogs = newLogs.map(line => ({
    ...parseLogLine(line),
    id: Date.now() + Math.random(),
    isNew: true
  }));

  // 添加到高亮列表
  const newIds = new Set(parsedLogs.map(log => log.id));
  setHighlightedIds(newIds);

  // 3秒后移除高亮
  setTimeout(() => {
    setHighlightedIds(new Set());
  }, 3000);

  setLogs(prevLogs => [...prevLogs, ...parsedLogs]);
}, []);
```

### 3. 性能优化

使用虚拟滚动处理大量日志：

```javascript
import { FixedSizeList } from 'react-window';

function LogTable({ logs }) {
  const Row = ({ index, style }) => (
    <div style={style} className="log-row">
      {renderLogRow(logs[index])}
    </div>
  );

  return (
    <FixedSizeList
      height={600}
      itemCount={logs.length}
      itemSize={50}
      width="100%"
    >
      {Row}
    </FixedSizeList>
  );
}
```

---

## 📝 最佳实践

### 1. 性能优化
- 限制内存中保存的日志数量（如最近1万条）
- 使用虚拟滚动处理大量数据
- 对日志解析做防抖处理

### 2. 用户体验
- 提供暂停/继续按钮
- 用户滚动时自动暂停自动滚动
- 新日志添加高亮提示
- 显示监控状态和统计信息

### 3. 错误处理
- 文件不存在或被删除时的处理
- 网络请求失败时的重试机制
- 文件权限不足时的提示

### 4. 资源管理
- 组件卸载时清理定时器
- 停止监控时清理文件监听器
- 设置合理的轮询间隔

---

## 🔄 部署建议

### 1. 后端部署

```bash
# 添加新的依赖（如果使用 WebSocket）
npm install ws

# 重启服务
pm2 restart log-parser-app
```

### 2. 前端部署

```bash
cd client
npm install react-window  # 如果使用虚拟滚动
npm run build
```

---

## 📊 监控指标

建议监控以下指标：
- 活跃监控连接数
- 文件读取延迟
- 内存使用情况
- 错误率

---

**现在您的日志分析器支持实时监控功能了！** 🎉
