import React, { useState, useCallback } from 'react';
import axios from 'axios';
import './App.css';
import Dashboard from './components/Dashboard';
import LogTable from './components/LogTable';
import FileUpload from './components/FileUpload';
import LogMonitor from './components/LogMonitor';

function App() {
  const [logs, setLogs] = useState([]);
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [currentLogPath, setCurrentLogPath] = useState(null); // 当前日志路径

  // 处理实时监控的新日志
  const handleNewLogs = useCallback((newLogs, info) => {
    console.log(`收到 ${newLogs.length} 条新日志, 总新增: ${info.count}`);
    
    // 限制最大日志数量（保留最新的10000条）
    setLogs(prevLogs => {
      const combined = [...prevLogs, ...newLogs];
      if (combined.length > 10000) {
        return combined.slice(-10000);
      }
      return combined;
    });

    // 更新统计信息（重新计算）
    if (newLogs.length > 0) {
      // 简单更新：重新计算统计
      // 注意：这里可以优化为增量更新统计
      setStatistics(prevStats => {
        if (!prevStats) return prevStats;
        
        // 增量更新总请求数
        return {
          ...prevStats,
          totalRequests: (prevStats.totalRequests || 0) + newLogs.length,
        };
      });
    }
  }, []);

  // 加载默认的 log.txt
  const loadDefaultLog = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get('/api/parse-default-log');
      setLogs(response.data.logs);
      setStatistics(response.data.statistics);
    } catch (err) {
      setError(err.response?.data?.error || '加载日志失败');
      console.error('加载日志失败:', err);
    } finally {
      setLoading(false);
    }
  };

  // 上传并解析日志文件
  const handleFileUpload = async (file) => {
    setLoading(true);
    setError(null);
    try {
      const formData = new FormData();
      formData.append('logFile', file);

      const response = await axios.post('/api/parse-log', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setLogs(response.data.logs);
      setStatistics(response.data.statistics);
    } catch (err) {
      setError(err.response?.data?.error || '上传文件失败');
      console.error('上传文件失败:', err);
    } finally {
      setLoading(false);
    }
  };

  // 通过路径解析日志文件
  const handlePathSubmit = async (logPath) => {
    setLoading(true);
    setError(null);
    setCurrentLogPath(logPath); // 记录当前日志路径
    try {
      const response = await axios.post('/api/parse-log-path', { logPath });
      setLogs(response.data.logs);
      setStatistics(response.data.statistics);
    } catch (err) {
      setError(err.response?.data?.error || '加载日志失败');
      console.error('加载日志失败:', err);
      setCurrentLogPath(null); // 失败时清空路径
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>📊 日志解析器</h1>
        <p>分析和可视化您的服务器日志</p>
      </header>

      <div className="container">
        <FileUpload 
          onFileUpload={handleFileUpload}
          onLoadDefault={loadDefaultLog}
          onPathSubmit={handlePathSubmit}
          loading={loading}
        />

        {/* 实时日志监控组件 */}
        {currentLogPath && (
          <LogMonitor 
            logPath={currentLogPath}
            onNewLogs={handleNewLogs}
          />
        )}

        {error && (
          <div className="error-message">
            ⚠️ {error}
          </div>
        )}

        {loading && (
          <div className="loading">
            <div className="spinner"></div>
            <p>正在解析日志...</p>
          </div>
        )}

        {statistics && !loading && (
          <>
            <div className="tabs">
              <button
                className={`tab ${activeTab === 'dashboard' ? 'active' : ''}`}
                onClick={() => setActiveTab('dashboard')}
              >
                📈 数据统计
              </button>
              <button
                className={`tab ${activeTab === 'logs' ? 'active' : ''}`}
                onClick={() => setActiveTab('logs')}
              >
                📋 日志详情
              </button>
            </div>

            <div className="tab-content">
              {activeTab === 'dashboard' && (
                <Dashboard statistics={statistics} logs={logs} />
              )}
              {activeTab === 'logs' && (
                <LogTable logs={logs} />
              )}
            </div>
          </>
        )}

        {!statistics && !loading && !error && (
          <div className="welcome">
            <h2>👋 欢迎使用日志解析器</h2>
            <p>请上传日志文件或加载默认日志开始分析</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
