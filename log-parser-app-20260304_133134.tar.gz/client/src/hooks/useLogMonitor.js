import { useState, useEffect, useRef, useCallback } from 'react';
import axios from 'axios';

/**
 * 日志实时监控 Hook
 * @param {string} logPath - 日志文件路径
 * @param {Object} options - 配置选项
 * @returns {Object} 监控状态和控制函数
 */
export function useLogMonitor(logPath, options = {}) {
  const {
    interval = 10000,      // 轮询间隔(毫秒)，默认10秒
    autoStart = false,     // 是否自动开始监控
    onNewLogs = null,      // 新日志回调函数
    onError = null,        // 错误回调函数
    maxRetries = 3,        // 最大重试次数
  } = options;

  const [isMonitoring, setIsMonitoring] = useState(autoStart);
  const [position, setPosition] = useState(0);
  const [fileSize, setFileSize] = useState(0);
  const [error, setError] = useState(null);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [totalNewLogs, setTotalNewLogs] = useState(0);
  
  const intervalRef = useRef(null);
  const retryCountRef = useRef(0);

  /**
   * 获取增量日志
   */
  const fetchIncrementalLogs = useCallback(async () => {
    if (!logPath) {
      console.warn('未提供日志路径');
      return;
    }

    try {
      const response = await axios.get('/api/logs/incremental', {
        params: { 
          path: logPath, 
          position: position 
        },
        timeout: 10000 // 10秒超时
      });

      if (response.data.success) {
        const { logs, newPosition, fileSize, count } = response.data.data;

        // 更新文件信息
        setFileSize(fileSize);
        setPosition(newPosition);
        setLastUpdate(new Date());

        // 如果有新日志
        if (logs.length > 0) {
          setTotalNewLogs(prev => prev + logs.length);
          
          if (onNewLogs) {
            onNewLogs(logs, {
              count,
              newPosition,
              fileSize
            });
          }
        }

        // 重置重试计数
        retryCountRef.current = 0;
        setError(null);
      }
    } catch (err) {
      console.error('获取增量日志失败:', err);
      
      const errorMsg = err.response?.data?.error || err.message || '获取日志失败';
      setError(errorMsg);

      // 重试逻辑
      retryCountRef.current += 1;
      if (retryCountRef.current >= maxRetries) {
        console.error(`已达到最大重试次数 (${maxRetries}), 停止监控`);
        stopMonitoring();
      }

      if (onError) {
        onError(errorMsg, retryCountRef.current);
      }
    }
  }, [logPath, position, onNewLogs, onError, maxRetries]);

  /**
   * 开始监控
   */
  const startMonitoring = useCallback(() => {
    if (!logPath) {
      console.warn('未提供日志路径，无法开始监控');
      return;
    }
    
    console.log(`开始监控日志: ${logPath}, 间隔: ${interval}ms`);
    setIsMonitoring(true);
    setError(null);
    retryCountRef.current = 0;
    
    // 立即执行一次
    fetchIncrementalLogs();
    
    // 设置定时器
    intervalRef.current = setInterval(fetchIncrementalLogs, interval);
  }, [logPath, interval, fetchIncrementalLogs]);

  /**
   * 停止监控
   */
  const stopMonitoring = useCallback(() => {
    console.log('停止监控日志');
    setIsMonitoring(false);
    
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  /**
   * 重置位置（从头开始）
   */
  const resetPosition = useCallback(() => {
    console.log('重置读取位置到文件开头');
    setPosition(0);
    setTotalNewLogs(0);
    
    if (isMonitoring) {
      fetchIncrementalLogs();
    }
  }, [isMonitoring, fetchIncrementalLogs]);

  /**
   * 跳到文件末尾
   */
  const seekToEnd = useCallback(async () => {
    if (!logPath) return;

    try {
      console.log('跳到文件末尾');
      const response = await axios.get('/api/logs/size', {
        params: { path: logPath }
      });
      
      if (response.data.success) {
        const size = response.data.size;
        setPosition(size);
        setFileSize(size);
        console.log(`当前位置: ${size} 字节`);
      }
    } catch (err) {
      console.error('获取文件大小失败:', err);
      setError(err.response?.data?.error || err.message);
    }
  }, [logPath]);

  /**
   * 手动刷新一次
   */
  const refreshOnce = useCallback(() => {
    console.log('手动刷新日志');
    return fetchIncrementalLogs();
  }, [fetchIncrementalLogs]);

  /**
   * 更改轮询间隔
   */
  const changeInterval = useCallback((newInterval) => {
    if (newInterval <= 0) {
      console.warn('间隔必须大于0');
      return;
    }

    console.log(`更改轮询间隔: ${newInterval}ms`);
    
    // 如果正在监控，重启
    if (isMonitoring) {
      stopMonitoring();
      setTimeout(() => {
        // 使用新的间隔重启
        setIsMonitoring(true);
        intervalRef.current = setInterval(fetchIncrementalLogs, newInterval);
      }, 100);
    }
  }, [isMonitoring, stopMonitoring, fetchIncrementalLogs]);

  /**
   * 自动开始监控
   */
  useEffect(() => {
    if (autoStart && logPath) {
      startMonitoring();
    }

    // 清理函数
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [logPath, autoStart]);

  /**
   * 监听 logPath 变化
   */
  useEffect(() => {
    if (logPath) {
      // 路径变化时重置状态
      setPosition(0);
      setFileSize(0);
      setTotalNewLogs(0);
      setError(null);
      setLastUpdate(null);
      retryCountRef.current = 0;
    }
  }, [logPath]);

  return {
    // 状态
    isMonitoring,
    position,
    fileSize,
    error,
    lastUpdate,
    totalNewLogs,
    retryCount: retryCountRef.current,
    
    // 控制函数
    startMonitoring,
    stopMonitoring,
    resetPosition,
    seekToEnd,
    refreshOnce,
    changeInterval,
    
    // 计算属性
    progress: fileSize > 0 ? (position / fileSize) * 100 : 0,
    canMonitor: !!logPath,
  };
}

export default useLogMonitor;
