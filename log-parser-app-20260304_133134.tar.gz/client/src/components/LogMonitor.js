import React, { useState, useEffect } from 'react';
import useLogMonitor from '../hooks/useLogMonitor';
import './LogMonitor.css';

/**
 * 日志实时监控控制面板组件
 */
function LogMonitor({ logPath, onNewLogs, className = '' }) {
  const [intervalInput, setIntervalInput] = useState('10');
  const [showDetails, setShowDetails] = useState(false);

  const {
    isMonitoring,
    position,
    fileSize,
    error,
    lastUpdate,
    totalNewLogs,
    retryCount,
    progress,
    canMonitor,
    startMonitoring,
    stopMonitoring,
    resetPosition,
    seekToEnd,
    refreshOnce,
    changeInterval,
  } = useLogMonitor(logPath, {
    interval: parseInt(intervalInput) * 1000,
    autoStart: false,
    onNewLogs: (logs, info) => {
      if (onNewLogs) {
        onNewLogs(logs, info);
      }
    },
    onError: (errorMsg, retry) => {
      console.error(`日志监控错误 (重试 ${retry}/3):`, errorMsg);
    },
    maxRetries: 3,
  });

  // 格式化文件大小
  const formatSize = (bytes) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  // 格式化时间
  const formatTime = (date) => {
    if (!date) return '-';
    return date.toLocaleTimeString('zh-CN', { 
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  // 处理间隔变更
  const handleIntervalChange = () => {
    const newInterval = parseInt(intervalInput);
    if (isNaN(newInterval) || newInterval < 1) {
      alert('请输入有效的间隔秒数（≥1）');
      return;
    }
    changeInterval(newInterval * 1000);
    alert(`轮询间隔已更新为 ${newInterval} 秒`);
  };

  // 切换监控状态
  const toggleMonitoring = () => {
    if (isMonitoring) {
      stopMonitoring();
    } else {
      startMonitoring();
    }
  };

  // 路径变化时，停止监控
  useEffect(() => {
    if (isMonitoring) {
      stopMonitoring();
    }
  }, [logPath]);

  if (!logPath) {
    return null; // 没有日志路径时不显示
  }

  return (
    <div className={`log-monitor ${className}`}>
      <div className="monitor-header">
        <h3>
          <span className="monitor-icon">📊</span>
          实时日志监控
          <span className={`monitor-status ${isMonitoring ? 'active' : 'inactive'}`}>
            {isMonitoring ? '●' : '○'}
          </span>
        </h3>
        <button 
          className="toggle-details-btn"
          onClick={() => setShowDetails(!showDetails)}
          title={showDetails ? '隐藏详情' : '显示详情'}
        >
          {showDetails ? '▼' : '▶'}
        </button>
      </div>

      <div className="monitor-main">
        {/* 控制按钮 */}
        <div className="monitor-controls">
          <button
            className={`btn-primary ${isMonitoring ? 'btn-stop' : 'btn-start'}`}
            onClick={toggleMonitoring}
            disabled={!canMonitor}
            title={isMonitoring ? '停止监控' : '开始监控'}
          >
            {isMonitoring ? '⏸ 停止' : '▶ 开始'}
          </button>

          <button
            className="btn-secondary"
            onClick={refreshOnce}
            disabled={!canMonitor || isMonitoring}
            title="手动刷新一次"
          >
            🔄 刷新
          </button>

          <button
            className="btn-secondary"
            onClick={resetPosition}
            disabled={!canMonitor}
            title="从头开始读取"
          >
            ⏮ 重置
          </button>

          <button
            className="btn-secondary"
            onClick={seekToEnd}
            disabled={!canMonitor}
            title="跳到文件末尾"
          >
            ⏭ 末尾
          </button>
        </div>

        {/* 基本信息 */}
        <div className="monitor-info">
          <div className="info-item">
            <span className="info-label">文件大小:</span>
            <span className="info-value">{formatSize(fileSize)}</span>
          </div>
          <div className="info-item">
            <span className="info-label">读取位置:</span>
            <span className="info-value">{formatSize(position)}</span>
          </div>
          <div className="info-item">
            <span className="info-label">新增日志:</span>
            <span className="info-value highlight">{totalNewLogs} 条</span>
          </div>
          <div className="info-item">
            <span className="info-label">最后更新:</span>
            <span className="info-value">{formatTime(lastUpdate)}</span>
          </div>
        </div>

        {/* 进度条 */}
        {fileSize > 0 && (
          <div className="monitor-progress">
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${progress}%` }}
              />
            </div>
            <span className="progress-text">{progress.toFixed(1)}%</span>
          </div>
        )}

        {/* 错误提示 */}
        {error && (
          <div className="monitor-error">
            <span className="error-icon">⚠️</span>
            {error}
            {retryCount > 0 && <span className="retry-info"> (重试 {retryCount}/3)</span>}
          </div>
        )}

        {/* 详细信息（可折叠） */}
        {showDetails && (
          <div className="monitor-details">
            <div className="detail-group">
              <label className="detail-label">
                轮询间隔（秒）:
                <div className="interval-control">
                  <input
                    type="number"
                    min="1"
                    max="300"
                    value={intervalInput}
                    onChange={(e) => setIntervalInput(e.target.value)}
                    disabled={isMonitoring}
                    className="interval-input"
                  />
                  <button
                    className="btn-small"
                    onClick={handleIntervalChange}
                    disabled={isMonitoring}
                  >
                    应用
                  </button>
                </div>
              </label>
            </div>

            <div className="detail-info">
              <div className="detail-item">
                <span className="detail-key">日志路径:</span>
                <span className="detail-value" title={logPath}>
                  {logPath.length > 50 ? `...${logPath.slice(-50)}` : logPath}
                </span>
              </div>
              <div className="detail-item">
                <span className="detail-key">监控状态:</span>
                <span className={`detail-value status-${isMonitoring ? 'on' : 'off'}`}>
                  {isMonitoring ? '运行中' : '已停止'}
                </span>
              </div>
            </div>

            <div className="detail-tips">
              <p>💡 <strong>使用提示:</strong></p>
              <ul>
                <li>点击"开始"按钮启动定时轮询，自动检测新日志</li>
                <li>监控运行时会每隔指定时间自动读取新增内容</li>
                <li>点击"停止"暂停监控，"刷新"可手动读取一次</li>
                <li>"重置"从头读取，"末尾"跳到文件最新位置</li>
                <li>切换日志文件会自动停止当前监控</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default LogMonitor;
