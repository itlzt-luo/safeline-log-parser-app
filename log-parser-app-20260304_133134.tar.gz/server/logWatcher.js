const fs = require('fs');
const readline = require('readline');

/**
 * 日志监控器 - 支持增量读取和文件监听
 */
class LogWatcher {
  constructor() {
    this.watchers = new Map(); // 存储文件监听器
    this.positions = new Map(); // 存储读取位置
  }

  /**
   * 增量读取日志
   * @param {string} filePath - 文件路径
   * @param {number} startPosition - 起始位置（字节）
   * @returns {Promise<Object>} 返回新日志和新位置
   */
  async readIncremental(filePath, startPosition = 0) {
    return new Promise((resolve, reject) => {
      // 检查文件是否存在
      if (!fs.existsSync(filePath)) {
        return reject(new Error('文件不存在'));
      }

      const stats = fs.statSync(filePath);
      const fileSize = stats.size;

      // 如果文件没有新内容
      if (startPosition >= fileSize) {
        return resolve({
          logs: [],
          newPosition: startPosition,
          fileSize: fileSize,
          hasMore: false
        });
      }

      const stream = fs.createReadStream(filePath, {
        start: startPosition,
        encoding: 'utf8'
      });

      const rl = readline.createInterface({
        input: stream,
        crlfDelay: Infinity
      });

      const newLogs = [];
      let bytesRead = startPosition;

      rl.on('line', (line) => {
        if (line.trim()) {
          newLogs.push(line);
          // 计算实际字节数（包括换行符）
          bytesRead += Buffer.byteLength(line, 'utf8') + 1;
        }
      });

      rl.on('close', () => {
        resolve({
          logs: newLogs,
          newPosition: bytesRead,
          fileSize: fileSize,
          hasMore: bytesRead < fileSize
        });
      });

      rl.on('error', (error) => {
        reject(new Error(`读取文件失败: ${error.message}`));
      });
    });
  }

  /**
   * 获取文件大小
   * @param {string} filePath - 文件路径
   * @returns {number} 文件大小（字节）
   */
  getFileSize(filePath) {
    try {
      if (!fs.existsSync(filePath)) {
        throw new Error('文件不存在');
      }
      const stats = fs.statSync(filePath);
      return stats.size;
    } catch (error) {
      throw new Error(`获取文件大小失败: ${error.message}`);
    }
  }

  /**
   * 监听文件变化
   * @param {string} filePath - 文件路径
   * @param {Function} callback - 变化时的回调函数
   */
  watchFile(filePath, callback) {
    if (this.watchers.has(filePath)) {
      console.log(`文件已在监听中: ${filePath}`);
      return;
    }

    try {
      // 初始化读取位置为文件末尾（只监听新增内容）
      const initialSize = this.getFileSize(filePath);
      this.positions.set(filePath, initialSize);

      const watcher = fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
          const position = this.positions.get(filePath) || 0;
          
          this.readIncremental(filePath, position)
            .then(result => {
              if (result.logs.length > 0) {
                this.positions.set(filePath, result.newPosition);
                callback(null, result);
              }
            })
            .catch(err => {
              console.error('读取文件增量失败:', err);
              callback(err, null);
            });
        }
      });

      watcher.on('error', (error) => {
        console.error(`文件监听错误 ${filePath}:`, error);
        this.unwatchFile(filePath);
      });

      this.watchers.set(filePath, watcher);
      console.log(`开始监听文件: ${filePath}`);
    } catch (error) {
      console.error(`启动文件监听失败:`, error);
      throw error;
    }
  }

  /**
   * 停止监听文件
   * @param {string} filePath - 文件路径
   */
  unwatchFile(filePath) {
    const watcher = this.watchers.get(filePath);
    if (watcher) {
      watcher.close();
      this.watchers.delete(filePath);
      this.positions.delete(filePath);
      console.log(`停止监听文件: ${filePath}`);
    }
  }

  /**
   * 停止所有监听
   */
  unwatchAll() {
    console.log(`停止所有文件监听 (${this.watchers.size} 个)`);
    this.watchers.forEach((watcher, filePath) => {
      watcher.close();
      console.log(`  - 停止监听: ${filePath}`);
    });
    this.watchers.clear();
    this.positions.clear();
  }

  /**
   * 获取当前监听的文件列表
   * @returns {Array} 文件路径数组
   */
  getWatchedFiles() {
    return Array.from(this.watchers.keys());
  }

  /**
   * 获取文件的当前读取位置
   * @param {string} filePath - 文件路径
   * @returns {number} 当前位置（字节）
   */
  getPosition(filePath) {
    return this.positions.get(filePath) || 0;
  }

  /**
   * 设置文件的读取位置
   * @param {string} filePath - 文件路径
   * @param {number} position - 位置（字节）
   */
  setPosition(filePath, position) {
    this.positions.set(filePath, position);
  }
}

// 导出单例
module.exports = new LogWatcher();
