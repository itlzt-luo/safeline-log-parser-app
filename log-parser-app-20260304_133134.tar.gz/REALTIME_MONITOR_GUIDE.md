# 实时日志监控功能使用指南

## 🎯 功能概述

实时日志监控功能允许您监控持续写入的日志文件，自动检测并加载新增的日志内容，无需手动刷新页面。

## ✨ 主要特性

- ✅ **增量读取**: 只读取新增的日志内容，节省带宽和服务器资源
- ✅ **定时轮询**: 可配置的自动刷新间隔（1-300秒）
- ✅ **实时更新**: 新日志自动追加到日志列表和图表
- ✅ **灵活控制**: 支持开始/停止/暂停/继续/重置/跳转
- ✅ **状态监控**: 实时显示文件大小、读取位置、新增日志数
- ✅ **错误处理**: 自动重试机制，最多重试3次
- ✅ **进度显示**: 可视化进度条显示读取进度

## 🚀 快速开始

### 1. 启动服务器（如果还没启动）

```bash
# 启动后端
cd /Volumes/Data/Work/Code/work/server
npm start

# 启动前端（新终端）
cd /Volumes/Data/Work/Code/work/client
npm start
```

### 2. 加载日志文件

在浏览器中打开应用，通过以下方式之一加载日志：

- **方式1**: 输入日志文件的绝对路径
  ```
  /Volumes/Data/Work/Code/work/log.txt
  ```

- **方式2**: 使用测试日志（持续写入）
  ```bash
  # 在项目根目录运行测试脚本
  cd /Volumes/Data/Work/Code/work
  ./generate-realtime-log.sh
  ```
  
  然后在应用中输入路径：
  ```
  /Volumes/Data/Work/Code/work/test-realtime.log
  ```

### 3. 开启实时监控

当您通过路径加载日志后，会自动显示"实时日志监控"面板：

1. **点击"▶ 开始"按钮** 启动定时轮询
2. 监控指示器变为绿色 🟢，表示监控运行中
3. 新的日志会自动追加到日志列表

## 🎮 控制面板说明

### 主要按钮

| 按钮 | 功能 | 说明 |
|------|------|------|
| **▶ 开始** | 启动监控 | 开始定时轮询，自动检测新日志 |
| **⏸ 停止** | 停止监控 | 暂停定时轮询 |
| **🔄 刷新** | 手动刷新 | 立即读取一次新日志（仅在停止状态可用） |
| **⏮ 重置** | 从头读取 | 将读取位置重置到文件开头 |
| **⏭ 末尾** | 跳到末尾 | 将读取位置跳到文件最新位置 |

### 状态信息

- **文件大小**: 当前日志文件的总大小
- **读取位置**: 已读取到的字节位置
- **新增日志**: 启动监控后新增的日志条数（带高亮）
- **最后更新**: 上次成功读取新日志的时间
- **进度条**: 显示已读取的百分比

### 详细设置（点击 ▶ 展开）

- **轮询间隔**: 设置自动刷新的间隔时间（1-300秒）
  - 默认: 10秒
  - 建议: 日志频繁更新时使用5-10秒，稳定日志使用30-60秒
  - 注意: 监控运行时无法更改，需先停止

## 📝 使用场景

### 场景1: 监控生产服务器日志

```bash
# 在服务器上找到日志路径
tail -f /var/log/nginx/access.log

# 在应用中输入该路径
/var/log/nginx/access.log

# 开启实时监控，间隔设为10秒
```

### 场景2: 本地开发调试

```bash
# 运行测试脚本（每3秒写入一条）
./generate-realtime-log.sh

# 在应用中加载测试日志
/Volumes/Data/Work/Code/work/test-realtime.log

# 开启监控，观察实时更新
```

### 场景3: 分析历史日志

```bash
# 加载大型历史日志
/path/to/large-log-file.log

# 点击"⏭ 末尾"跳到最新位置
# 开启监控，只关注最新的日志
```

## 🔧 高级用法

### 1. 调整轮询间隔

```javascript
// 在 LogMonitor 组件中，默认间隔是 10 秒
// 可以通过界面调整：

1. 点击详情面板展开
2. 在"轮询间隔"输入框输入新的秒数（如 5）
3. 点击"应用"按钮
4. 停止并重新开始监控以使用新间隔
```

### 2. 编程方式使用 Hook

```javascript
import { useLogMonitor } from './hooks/useLogMonitor';

function MyComponent() {
  const {
    isMonitoring,
    position,
    fileSize,
    error,
    startMonitoring,
    stopMonitoring,
    // ... 更多控制函数
  } = useLogMonitor('/path/to/log', {
    interval: 5000,       // 5秒轮询
    autoStart: true,      // 自动开始
    maxRetries: 5,        // 最多重试5次
    onNewLogs: (logs) => {
      console.log('收到新日志:', logs);
    },
    onError: (error) => {
      console.error('监控错误:', error);
    }
  });

  return (
    <div>
      <button onClick={startMonitoring}>开始</button>
      <button onClick={stopMonitoring}>停止</button>
      <p>进度: {((position / fileSize) * 100).toFixed(1)}%</p>
    </div>
  );
}
```

### 3. 自定义样式

修改 `LogMonitor.css` 来自定义监控面板的外观：

```css
/* 修改主题色 */
.log-monitor {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

/* 修改按钮样式 */
.btn-primary {
  background: #4ade80;
  color: white;
}
```

## 🐛 常见问题

### Q1: 监控没有显示新日志？

**原因**: 
- 日志文件没有新内容写入
- 轮询间隔太长
- 读取位置在文件末尾

**解决**:
1. 确认日志文件确实在更新（使用 `tail -f` 命令验证）
2. 减小轮询间隔（改为5秒）
3. 点击"重置"从头开始读取

### Q2: 出现错误提示？

**原因**:
- 文件路径不存在或无权限
- 服务器未启动
- 网络连接问题

**解决**:
1. 检查文件路径是否正确
2. 确认后端服务器正在运行（http://localhost:3001）
3. 查看浏览器控制台的错误信息
4. 系统会自动重试，最多3次

### Q3: 日志数量太多，页面卡顿？

**原因**: 加载的日志条数过多（>10000条）

**解决**:
1. 应用自动保留最新的10000条日志
2. 使用"跳到末尾"功能，只关注最新日志
3. 考虑增加轮询间隔，减少更新频率

### Q4: 切换日志文件后，监控还在运行？

**自动处理**: 当您加载新的日志文件时，系统会自动停止之前的监控

## 📊 性能优化建议

### 1. 合理设置轮询间隔

| 日志更新频率 | 推荐间隔 |
|------------|---------|
| 每秒多条 | 5秒 |
| 每分钟数条 | 10-20秒 |
| 每小时数条 | 60-120秒 |
| 不频繁更新 | 使用手动刷新 |

### 2. 使用"跳到末尾"功能

对于大型日志文件（>100MB），建议：
1. 加载文件后立即点击"⏭ 末尾"
2. 这样只会读取最新的内容
3. 避免加载整个历史日志

### 3. 限制日志数量

应用内置了10000条的限制，超过时自动保留最新的记录。如需修改：

```javascript
// 在 App.js 中修改 handleNewLogs 函数
setLogs(prevLogs => {
  const combined = [...prevLogs, ...newLogs];
  const maxLogs = 5000; // 修改为你需要的数量
  if (combined.length > maxLogs) {
    return combined.slice(-maxLogs);
  }
  return combined;
});
```

## 🔮 未来增强功能

已在 `REALTIME_LOG_FEATURE.md` 中详细描述，包括：

- **WebSocket实时推送**: 服务器主动推送新日志，零延迟
- **智能暂停**: 检测用户正在查看时暂停自动滚动
- **日志高亮**: 新日志带有淡入效果，3秒后恢复
- **虚拟滚动**: 使用 react-window 优化大量日志的渲染
- **日志过滤**: 实时过滤特定IP、状态码、路径
- **导出功能**: 导出监控期间的新增日志

## 📖 相关文档

- **完整技术方案**: `REALTIME_LOG_FEATURE.md`
- **API文档**: 查看 `server/index.js` 中的路由定义
- **Hook源码**: `client/src/hooks/useLogMonitor.js`
- **组件源码**: `client/src/components/LogMonitor.js`

## 🆘 获取帮助

如果遇到问题：

1. 查看浏览器控制台（F12）的错误信息
2. 查看服务器日志（终端输出）
3. 参考 `REALTIME_LOG_FEATURE.md` 的详细技术说明
4. 使用测试脚本验证功能是否正常

---

**祝您使用愉快！** 🎉
