#!/bin/bash

# 实时日志监控测试脚本
# 该脚本会持续向 test-realtime.log 写入新的日志行

LOG_FILE="test-realtime.log"
INTERVAL=3  # 每3秒写入一条

echo "开始生成测试日志到: $LOG_FILE"
echo "按 Ctrl+C 停止"
echo ""

# 创建或清空日志文件
> "$LOG_FILE"

counter=1

while true; do
  # 生成随机IP
  IP="192.168.1.$((RANDOM % 255))"
  
  # 生成随机状态码
  STATUS_CODES=(200 200 200 304 404 500)
  STATUS=${STATUS_CODES[$((RANDOM % ${#STATUS_CODES[@]}))]}
  
  # 生成随机路径
  PATHS=("/api/users" "/api/posts" "/api/comments" "/index.html" "/static/style.css" "/images/logo.png")
  PATH=${PATHS[$((RANDOM % ${#PATHS[@]}))]}
  
  # 生成随机大小
  SIZE=$((RANDOM % 10000 + 100))
  
  # 当前时间
  TIMESTAMP=$(date '+%d/%b/%Y:%H:%M:%S %z')
  
  # 写入日志行
  LOG_LINE="$IP - - [$TIMESTAMP] \"GET $PATH HTTP/1.1\" $STATUS $SIZE \"-\" \"Mozilla/5.0\""
  echo "$LOG_LINE" >> "$LOG_FILE"
  
  echo "[$counter] 写入: $IP - $STATUS - $PATH"
  
  counter=$((counter + 1))
  sleep $INTERVAL
done
